package TYUT;

public class User {
    private String Name;
    private String password;

    /**有参构造函数
     *
     * @param name
     * @param password
     */
    public User(String name, String password) {
        Name = name;
        this.password = password;
    }

    /**
     * 无参构造函数
     */
    public User() {
        this.Name = "";
        this.password = "";
    }

    /*生成 get set 方法*/
    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }



}

package TYUT;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class emailListServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String url = "";
        String userName = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String source = "";
        if(userName == null && password == null){
            System.out.println("没有从index过来,直接访问了本Servlet!");
            source = "illegal";
        }
        if(source.equals("illegal")){
            url = "/index.jsp";
        }else {
            /*
            *这里处理 User.java UserDB.java
            * User thisUser = new User(userName, password);
            *
            * */
            request.setAttribute("userName", userName);
            request.setAttribute("password", password);
            request.setAttribute("email", email);
            url = "/thanks.jsp";
            getServletContext().getRequestDispatcher(url).forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

}
